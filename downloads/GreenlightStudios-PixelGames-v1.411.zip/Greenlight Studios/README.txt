Greenlight Studios - Pixel Smash & Pixel Smash Kart (browser builds)

1. Unzip this folder anywhere.
2. Double-click a .html file. It opens in your web browser and plays right away.
   Works in Chrome, Edge, Firefox and Safari on Windows, Mac, Linux and ChromeOS.

Both games share one save and one online username. Use the Save data menu in
either game to copy a save code and move your progress between devices.

Fonts and online play need an internet connection; everything else runs offline.
